package com.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.web.model.Account;
import com.web.service.AccountService;
import com.web.view.AccountView;

@Controller
public class AccountController {

	@Autowired
	private AccountService acs;
	@RequestMapping("/")
	public String home() {
		return "home";
	}
	@RequestMapping("/reg")
	public String reg() {
		return "reg";
	}
	@RequestMapping("register")
	@ResponseBody
	public String registerNew(AccountView acv) {
		return acs.registerNew(acv);
	}
	@RequestMapping("bal")
	public String viewB() {
		return "balance";
	}
	@RequestMapping("viewBal")
	public String viewBal(Account ac,Model m) {
		m.addAttribute("res", acs.showBal(ac));
		return "showBal";
	}
	@RequestMapping("depo")
	public String dep() {
		return "deposite";
	}
	@RequestMapping("deposite")
	@ResponseBody
	public String depositeAm(Account ac) {
		return acs.depositeAm(ac);
	}
	@RequestMapping("wid")
	public String width() {
		return "widthdraw";
	}
	@RequestMapping("widthdraw")
	@ResponseBody
	public String widthdrawAm(Account ac) {
		return acs.withdrawAm(ac);
	}
	@RequestMapping("tra")
	public String tra() {
		return "transfer";
	}
	@RequestMapping("transfer")
	@ResponseBody
	public String transferAm(AccountView acv) {
		return acs.transferAm(acv);
	}
	@RequestMapping("del")
	public String del() {
		return "delete";
	}
	@RequestMapping("delete")
	@ResponseBody
	public String deleteAc(Account ac) {
		return acs.deleteAc(ac);
	}
	@RequestMapping("about")
	public String about() {
		return "about";
	}
}
