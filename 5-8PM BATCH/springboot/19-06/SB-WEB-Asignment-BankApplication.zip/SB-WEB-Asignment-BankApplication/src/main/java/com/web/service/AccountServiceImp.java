package com.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.model.Account;
import com.web.repository.AccountRepo;
import com.web.view.AccountView;

@Service
public class AccountServiceImp implements AccountService {

	@Autowired
	private AccountRepo ar;

	@Override
	public String registerNew(AccountView acv) {
		String res = "";
		if (acv.getPassword().equals(acv.getConformPassword())) {
			Account ac = new Account();
			ac.setAccountNo(acv.getAccountNo());
			ac.setName(acv.getName());
			ac.setPassword(acv.getPassword());
			ac.setAddress(acv.getAddress());
			ac.setMobile(acv.getMobile());
			ac.setAmount(acv.getAmount());
			ar.save(ac);
			res = "Registration Success";
		} else
			res = "Conform Password Not Matched";
		return res;
	}

	@Override
	public String showBal(Account ac) {
		Account ac1 = ar.findById(ac.getAccountNo()).get();
		if (ac.getName().equalsIgnoreCase(ac1.getName()) && ac.getPassword().equals(ac1.getPassword()))
			return "Your Current Balance is " + ac1.getAmount();
		else
			return "Invalid User Name or Password";
	}

	@Override
	public String withdrawAm(Account ac) {
		Account ac1 = ar.findById(ac.getAccountNo()).get();
		if (ac.getName().equalsIgnoreCase(ac1.getName()) && ac.getPassword().equals(ac1.getPassword())) {
			if(ac1.getAmount() >= ac.getAmount()) {
			ac1.setAmount(ac1.getAmount() - ac.getAmount());
			ar.save(ac1);
			return "Your Balance is " + (ac1.getAmount() + ac.getAmount())
					+ " your Balance After widthdraw is " + ac1.getAmount();
			}
			else
				return "Inseficent Funds in Your Account";
		} else
			return "Invalid User Name or Password";
	}

	@Override
	public String depositeAm(Account ac) {
		Account ac1 = ar.findById(ac.getAccountNo()).get();
		if (ac.getName().equalsIgnoreCase(ac1.getName()) && ac.getPassword().equals(ac1.getPassword())) {
			ac1.setAmount(ac1.getAmount() + ac.getAmount());
			ar.save(ac1);
			return "Your Balance is " + (ac1.getAmount() - ac.getAmount()) + " your Balance After Deposite is "
					+ ac1.getAmount();
		} else
			return "Invalid User Name or Password";
	}

	@Override
	public String transferAm(AccountView acv) {
		Account ac1 = ar.findById(acv.getAccountNo()).get();
		Account ac2 = ar.findById(acv.getTargetAccountNo()).get();
		if (acv.getName().equalsIgnoreCase(ac1.getName()) && acv.getPassword().equals(ac1.getPassword())) {
			ac1.setAmount(ac1.getAmount() - acv.getAmount());
			ac2.setAmount(ac2.getAmount() + acv.getAmount());
			ar.save(ac1);
			ar.save(ac2);
			return "Your Balance is " + (ac1.getAmount() + acv.getAmount())
					+ " your Balance After Transfer is " + ac1.getAmount()
					+" Target Ac Balance is "+(ac2.getAmount()-acv.getAmount())
					+" Target Ac Balance After Transfer is " + ac2.getAmount();
		} else
			return "Invalid User Name or Password";
	}

	@Override
	public String deleteAc(Account ac) {
		Account ac1 = ar.findById(ac.getAccountNo()).get();
		if (ac.getName().equalsIgnoreCase(ac1.getName()) && ac.getPassword().equals(ac1.getPassword()))
			return "Account Delete Success";
		else
			return "Invalid User Name or Password";
	}

}
