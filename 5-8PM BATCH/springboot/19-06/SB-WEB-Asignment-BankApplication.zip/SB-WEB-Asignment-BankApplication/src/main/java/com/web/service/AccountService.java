package com.web.service;

import com.web.model.Account;
import com.web.view.AccountView;

public interface AccountService {
public String registerNew(AccountView acv);
public String showBal(Account ac);
public String withdrawAm(Account ac);
public String depositeAm(Account ac);
public String transferAm(AccountView acv);
public String deleteAc(Account ac);
}
